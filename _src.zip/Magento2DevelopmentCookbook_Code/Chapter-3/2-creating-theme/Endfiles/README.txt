Paste the Packt folder and contents in the app/design/frontend folder of your magento application. 

Clean the cache and run the command

php bin/magento setup:upgrade