Paste the Packt folder and contents in the app/code folder of your Magento application. 

Clean the cache and run the command

php bin/magento setup:upgrade